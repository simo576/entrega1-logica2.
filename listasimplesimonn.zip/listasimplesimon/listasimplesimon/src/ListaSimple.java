import java.util.ArrayList;

public class ListaSimple {
    public static void main(String[] args) {
        // Crear una lista de tipo String
        ArrayList<String> lista = new ArrayList<>();

        // Agregar elementos a la lista
        lista.add("Manzana");
        lista.add("Banana");
        lista.add("Cereza");

        // Imprimir los elementos de la lista
        System.out.println("Elementos de la lista:");
        for (String elemento : lista) {
            System.out.println(elemento);
        }

        // Eliminar un elemento de la lista
        lista.remove("Banana");

        // Imprimir la lista después de eliminar un elemento
        System.out.println("\nDespués de eliminar 'Banana':");
        for (String elemento : lista) {
            System.out.println(elemento);
        }

        // Verificar si un elemento está en la lista
        if (lista.contains("Manzana")) {
            System.out.println("\nLa lista contiene 'Manzana'.");
        } else {
            System.out.println("\nLa lista no contiene 'Manzana'.");
        }
    }
}