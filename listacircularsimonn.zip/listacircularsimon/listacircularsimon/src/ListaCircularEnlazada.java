import javax.swing.JOptionPane;

class Nodo {
    int dato;
    Nodo siguiente;

    public Nodo(int dato) {
        this.dato = dato;
        this.siguiente = null;
    }
}

public class ListaCircularEnlazada {
    private Nodo cabeza = null;
    private Nodo cola = null;

    // Método para agregar un nodo a la lista
    public void agregar(int dato) {
        Nodo nuevoNodo = new Nodo(dato);

        if (cabeza == null) {
            cabeza = nuevoNodo;
            cola = nuevoNodo;
            cola.siguiente = cabeza;
        } else {
            cola.siguiente = nuevoNodo;
            cola = nuevoNodo;
            cola.siguiente = cabeza;
        }
    }

    // Método para mostrar los nodos de la lista
    public void mostrar() {
        if (cabeza == null) {
            JOptionPane.showMessageDialog(null, "La lista está vacía.");
            return;
        }

        Nodo actual = cabeza;
        StringBuilder elementos = new StringBuilder("Elementos en la lista circular:\n");
        do {
            elementos.append(actual.dato).append(" ");
            actual = actual.siguiente;
        } while (actual != cabeza);

        JOptionPane.showMessageDialog(null, elementos.toString());
    }

    public static void main(String[] args) {
        ListaCircularEnlazada lista = new ListaCircularEnlazada();
        int opcion;

        do {
            String menu = "Seleccione una opción:\n"
                    + "1. Agregar un nodo\n"
                    + "2. Mostrar lista\n"
                    + "3. Salir";
            opcion = Integer.parseInt(JOptionPane.showInputDialog(menu));

            switch (opcion) {
                case 1:
                    int dato = Integer.parseInt(JOptionPane.showInputDialog("Ingrese un número para agregar a la lista:"));
                    lista.agregar(dato);
                    JOptionPane.showMessageDialog(null, "Número agregado con éxito.");
                    break;
                case 2:
                    lista.mostrar();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Saliendo del programa.");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida. Por favor, intente de nuevo.");
            }
        } while (opcion != 3);
    }
}